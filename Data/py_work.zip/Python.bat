@echo off
c:
cd\
cd users\_user\py_work

cmd
