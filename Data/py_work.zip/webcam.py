import cv2

cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)

if not cap.isOpened():
    print("Cannot open camera")
    exit()

while True:

    ret, frame = cap.read()

    if not ret:
        print("Cannot receive frame")
        break

    # image processing
    src = frame

    cv2.imshow("Webcam", src)

    key = cv2.waitKey(10) & 0xFF

    if key == 27:
        break

cap.release()
cv2.destroyAllWindows()